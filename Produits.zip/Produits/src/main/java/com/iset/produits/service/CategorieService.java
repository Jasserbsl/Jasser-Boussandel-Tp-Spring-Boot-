package com.iset.produits.service;

import com.iset.produits.entities.Categorie;
import com.iset.produits.entities.Produit;
import org.springframework.data.domain.Page;

import java.util.List;

public interface CategorieService {
    Categorie saveCategorie(Categorie p);
    Categorie updateCategorie(Categorie p);
    void deleteCategorie(Categorie p);
    void deleteCategorieById(Long id);
    Categorie getCategorie(Long id);
    List<Categorie> getAllCategories();
    Page<Categorie> getAllCategoriesParPage(int page, int size);
    List<Categorie> findByNomCategorie(String nom);
    List<Categorie> findByNomCategorieContains(String nom);

}
