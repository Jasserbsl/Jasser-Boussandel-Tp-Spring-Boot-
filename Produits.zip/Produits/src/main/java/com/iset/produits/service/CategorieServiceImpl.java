package com.iset.produits.service;

import com.iset.produits.dao.CategorieRepository;
import com.iset.produits.dao.ProduitRepository;
import com.iset.produits.entities.Categorie;
import com.iset.produits.entities.Produit;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageRequest;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class CategorieServiceImpl implements CategorieService{
    @Autowired
    CategorieRepository categorieRepository;
    @Override
    public Categorie saveCategorie(Categorie p) {
        return categorieRepository.save(p);
    }
    @Override
    public Categorie updateCategorie(Categorie p) {
        return categorieRepository.save(p);
    }
    @Override
    public void deleteCategorie(Categorie p) {
        categorieRepository.delete(p);
    }
    @Override
    public void deleteCategorieById(Long id) {
        categorieRepository.deleteById(id);
    }
    @Override
    public Categorie getCategorie(Long id) {
        return categorieRepository.findById(id).get();
    }
    @Override
    public List<Categorie> getAllCategories() {
        return categorieRepository.findAll();
    }
    @Override
    public Page<Categorie> getAllCategoriesParPage(int page, int size) {
// TODO Auto-generated method stub
        return categorieRepository.findAll(PageRequest.of(page, size));
    }

    @Override
    public List<Categorie> findByNomCategorie(String nom) {
        return null;
    }

    @Override
    public List<Categorie> findByNomCategorieContains(String nom) {
        return null;
    }

}
